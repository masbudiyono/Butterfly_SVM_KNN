from sklearn import svm
from tkinter import *                       # Library untuk tampilan GUI
from tkinter import filedialog
from tkinter import ttk
from PIL import ImageTk, Image              # Library untuk Image Processing
from sklearn.neighbors import KNeighborsClassifier
import pandas
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
import joblib
from skimage.feature import greycomatrix, greycoprops
from skimage import io
import cv2,os, csv,numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import average_precision_score
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import plot_precision_recall_curve
import matplotlib.pyplot as plt

image_size=(256,256)

features=['contrast', 'dissimilarity', 'homogeneity', 'energy', 'correlation', 'ASM']
nama=['Danaus plexippus','Heliconius charitonius','Heliconius erato','Junonia coenia','Lycaena phlaeas','Nymphalis antiopa','Papilio cresphontes','Pieris rapae','Vanessa atalanta','Vanessa cardui']


def histogram(file):
    image = cv2.imread(file,0)
    return cv2.calcHist([image], [0], None, [256], [0, 255])

def extract_roix(im):
    img = cv2.cvtColor(im, cv2.COLOR_BGR2LAB)[:, :, 2]
    thresh=cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    roi = cv2.resize(img, image_size)
    return roi,im,thresh


def extract_roi(im):
    original = im.copy()
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    thresh = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

    # Memberi Kotak Pada ROI
    x, y, w, h = cv2.boundingRect(thresh)
    cv2.rectangle(im, (x, y), (x + w, y + h), (36, 255, 12), 2)
    col = original[y:y + h, x:x + w]

    # Memberi alpha channel pada ROI
    b, g, r = cv2.split(original)
    alpha = np.ones(b.shape, dtype=b.dtype) * 50
    roi = cv2.merge([b, g, r, alpha])
    roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    roi =cv2.resize(roi,image_size)
    return roi,col,thresh

def extract_feature():
    global features
    try:
        os.remove('histogram.csv')

    except:
        pass
    dataset = os.listdir('dataset')
    cnt = 1
    for c in dataset:
        if not os.path.exists('background/' + c):
            os.makedirs('background/' + c.lower())
        for f in os.listdir(os.path.join('dataset/', c)):
            image = io.imread(os.path.join('dataset/', c, f))
            image = cv2.cvtColor(image, cv2.COLOR_RGBA2BGR)
            roi,col,thresh = extract_roi(image)
            glcm = greycomatrix(roi, [1], [0], 256, symmetric=False, normed=True)
            cv2.imwrite(os.path.join('background/', c, f),thresh)
            fco = []
            for ft in features:
                fco.append(greycoprops(glcm, ft)[0][0])
            fco.append(int(c)-1)
            cf = open('GLCM.csv', 'a+', newline='')
            writer = csv.writer(cf)
            print(str(cnt), '.', fco)
            writer.writerow(fco)
            cf.close()
            cnt += 1

def cur_glcm(im):
    global features
    image = io.imread(im)
    image = cv2.cvtColor(image, cv2.COLOR_RGBA2BGR)
    roi,col,thresh = extract_roi(image)
    glcm = greycomatrix(roi, [1], [0], 256, symmetric=False, normed=True)
    fco = []
    for ft in features:
        fco.append(greycoprops(glcm, ft)[0][0])
    return fco

def open_file():
    global nama
    global features
    path = filedialog.askopenfilename()
    if not path:
        return
    image = io.imread(path)
    image = cv2.cvtColor(image, cv2.COLOR_RGBA2RGB)
    roi,col,thresh=extract_roi(image)
    imgpanel = Image.fromarray(col)
    imgpanel = ImageTk.PhotoImage(imgpanel)
    picPanel.configure(image=imgpanel)
    picPanel.image = imgpanel

    imgsegmen = Image.fromarray(thresh)
    imgsegmen = ImageTk.PhotoImage(imgsegmen)
    picSegmen.configure(image=imgsegmen)
    picSegmen.image = imgsegmen

    # SVM
    loaded_model = joblib.load('SVM.sav')
    gbr = cur_glcm(path)
    gbr = np.array(gbr)
    gbr = gbr.reshape(1, -1)
    hasilSVM.configure(text=nama[int(loaded_model.predict(gbr))])
    #print(nama[int(loaded_model.predict(gbr))])
    ##
    val_glcm=cur_glcm(path)
    for i in tree.get_children():
        tree.delete(i)
    cnt=0
    for g in val_glcm:
        dt=[]
        dt.append(features[cnt])
        dt.append(g)
        tree.insert("", END, values=dt)
        cnt+=1

    #KNN
    fts = features.copy()
    fts.append('species')
    dataframe = pandas.read_csv('GLCM.csv', names=fts)
    array = dataframe.values
    cntf = len(features)
    X = array[:, 0:cntf]
    Y = array[:, cntf]
    test_size = 0.4;
    seed = 7
    X_train, X_test, Y_train, Y_test = model_selection.train_test_split(X, Y, test_size=test_size, random_state=seed)
    neighbor = 3
    model = KNeighborsClassifier(neighbor)
    model.fit(X_train, Y_train)
    gbr = cur_glcm(path)
    gbr = np.array(gbr)
    gbr = gbr.reshape(1, -1)
    hasilKNN.configure(text=nama[int(model.predict(gbr))])

'''
def training():
    global features
    global nama
    extract_feature()
    fts = features.copy()
    fts.append('species')
    dataframe = pandas.read_csv('glcm.csv', names=fts)
    array = dataframe.values
    cntf = len(features)
    X = array[:, 0:cntf]
    Y = array[:, cntf]
    test_size = 0.33
    seed = 7
    X_train, X_test, Y_train, Y_test = model_selection.train_test_split(X, Y, test_size=test_size, random_state=seed)
    model = LogisticRegression(solver='liblinear')
    model.fit(X_train, Y_train)
    # save the model to disk
    filename = 'SVM.sav'
    joblib.dump(model, filename)

    loaded_model = joblib.load(filename)
    result = loaded_model.score(X_test, Y_test)
    print("[INFO] SVM Accuracy: {:.2f}%".format(result * 100))



    X_train, X_test, Y_train, Y_test = model_selection.train_test_split(X, Y, test_size=test_size, random_state=seed)
    neighbor = len(nama)
    model = KNeighborsClassifier(neighbor)
    model.fit(X_train, Y_train)
    acc = model.score(X_test, Y_test)
    print("[INFO] k-NN Classifier: k=%d" % neighbor)
    print("[INFO] k-NN Accuracy: {:.2f}%".format(acc * 100))
'''
def training():
    extract_feature()
    dataframe = pandas.read_csv('glcm.csv')
    array = dataframe.values
    X = array[:, 0:6]
    y = array[:, 6]

    # Add noisy features

    random_state = np.random.RandomState(0)
    n_samples, n_features = X.shape
    # X = np.c_[X, random_state.randn(n_samples, 200 * n_features)]

    # Limit to the two first classes, and split into training and test
    X_train, X_test, y_train, y_test = train_test_split(X[y < 2], y[y < 2],
                                                        test_size=.5,
                                                        random_state=random_state)

    # Create a simple classifier
    classifier = svm.LinearSVC(random_state=random_state, dual=False)
    classifier.fit(X_train, y_train)
    y_score = classifier.decision_function(X_test)
    joblib.dump(classifier, "SVM.sav")
    loaded_model = joblib.load("SVM.sav")
    result = loaded_model.score(X_test, y_test)
    print("SVM Evaluation")
    print("SVM=> Accuracy: {:.2f}%".format(result * 100))
    ev="Accuracy: {:.2f}% | ".format(result * 100)
    # %%
    # Compute the average precision score
    # ...................................
    from sklearn.metrics import average_precision_score
    average_precision = average_precision_score(y_test, y_score)
    print('Precision : {0:0.2f} |'.format(average_precision))
    ev=ev+'Precision : {0:0.2f} |'.format(average_precision)

    # %%
    # Plot the Precision-Recall curve
    # ................................
    from sklearn.metrics import precision_recall_curve
    from sklearn.metrics import plot_precision_recall_curve
    import matplotlib.pyplot as plt

    disp = plot_precision_recall_curve(classifier, X_test, y_test)
    disp.ax_.set_title('2-class Precision-Recall curve: '
                       'AP={0:0.2f}'.format(average_precision))


    # %%
    # In multi-label settings
    # ------------------------
    #
    # Create multi-label data, fit, and predict
    # ...........................................
    #
    # We create a multi-label dataset, to illustrate the precision-recall in
    # multi-label settings

    from sklearn.preprocessing import label_binarize

    # Use label_binarize to be multi-label like settings
    Y = label_binarize(y, classes=[0, 1, 2])
    n_classes = Y.shape[1]

    # Split into training and test
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=.5,
                                                        random_state=random_state)

    # We use OneVsRestClassifier for multi-label prediction
    from sklearn.multiclass import OneVsRestClassifier

    # Run classifier
    classifier = OneVsRestClassifier(svm.LinearSVC(random_state=random_state, dual=False))
    # classifier=LogisticRegression(solver='liblinear')
    classifier.fit(X_train, Y_train)
    y_score = classifier.decision_function(X_test)

    # %%
    # The average precision score in multi-label settings
    # ....................................................
    from sklearn.metrics import precision_recall_curve
    from sklearn.metrics import average_precision_score

    # For each class
    precision = dict()
    recall = dict()
    average_precision = dict()
    for i in range(n_classes):
        precision[i], recall[i], _ = precision_recall_curve(Y_test[:, i],
                                                            y_score[:, i])
        average_precision[i] = average_precision_score(Y_test[:, i], y_score[:, i])

    # A "micro-average": quantifying score on all classes jointly
    precision["micro"], recall["micro"], _ = precision_recall_curve(Y_test.ravel(),
                                                                    y_score.ravel())
    average_precision["micro"] = average_precision_score(Y_test, y_score,
                                                         average="micro")
    print('Precision-Recall : {0:0.2f}'
          .format(average_precision["micro"]))
    ev=ev+'Precision-Recall : {0:0.2f} |'.format(average_precision["micro"])
    # %%
    # Plot the micro-averaged Precision-Recall curve
    # ...............................................
    #

    plt.figure()
    plt.step(recall['micro'], precision['micro'], where='post')

    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.ylim([0.0, 1.05])
    plt.xlim([0.0, 1.0])
    plt.title(
        'Rerata precision score, Micro-Averaged tiap Species: AP={0:0.2f}'
            .format(average_precision["micro"]))

    # %%
    # Plot Precision-Recall curve for each class and iso-f1 curves
    # .............................................................
    #
    from itertools import cycle
    # setup plot details
    colors = cycle(['navy', 'turquoise', 'darkorange', 'cornflowerblue', 'teal'])

    plt.figure(figsize=(7, 8))
    f_scores = np.linspace(0.2, 0.8, num=4)
    avgf_scores=sum(f_scores) / len(f_scores)
    print('F-1 Score : {0:0.2f}'.format(avgf_scores))
    ev=ev+'F-1 Score : {0:0.2f}'.format(avgf_scores)
    lbEvaluationSVM.configure(text=ev)
    lines = []
    labels = []
    for f_score in f_scores:
        x = np.linspace(0.01, 1)
        y = f_score * x / (2 * x - f_score)
        l, = plt.plot(x[y >= 0], y[y >= 0], color='gray', alpha=0.2)
        plt.annotate('f1={0:0.1f}'.format(f_score), xy=(0.9, y[45] + 0.02))

    lines.append(l)
    labels.append('iso-f1 curves')
    l, = plt.plot(recall["micro"], precision["micro"], color='gold', lw=2)
    lines.append(l)
    labels.append('micro-average Precision-recall (area = {0:0.2f})'
                  ''.format(average_precision["micro"]))

    for i, color in zip(range(n_classes), colors):
        l, = plt.plot(recall[i], precision[i], color=color, lw=2)
        lines.append(l)
        labels.append('Precision-recall for class {0} (area = {1:0.2f})'
                      ''.format(i, average_precision[i]))

    fig = plt.gcf()
    fig.subplots_adjust(bottom=0.25)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Kurva Extension Precision-Recall Multi-Class')
    plt.legend(lines, labels, loc=(0, -.38), prop=dict(size=14))

    plt.show()


def knn_evaluation():
    dataframe = pandas.read_csv('glcm.csv')
    array = dataframe.values
    X = array[:, 0:6]
    y = array[:, 6]
    X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=0.33, random_state=7)
    neighbor = len(nama)
    model = KNeighborsClassifier(neighbor)
    model.fit(X_train, y_train)
    acc = model.score(X_test, y_test)
    print("KNN Evaluation:")
    print("[INFO] k-NN Classifier: k=%d" % neighbor)
    print("[INFO] k-NN Accuracy: {:.2f}%".format(acc * 100))
    ev="KNN => k:%d |" % neighbor
    ev=ev+"Accuracy:{:.2f}%".format(acc * 100)
    lbEvaluationKNN.configure(text=ev)

# Window GUI
root = Tk()
root.title("Deteksi Butterfly dengan Extraksi Fitur GLCM Menggunakan Metode SVM dan KNN")
root.geometry('750x450')
root.eval('tk::PlaceWindow . center')
##########
lbPanel=Label(text="GLCM",anchor="w")
lbPanel.place(x = 550, y = 30 , width=50, height=25)
tree = ttk.Treeview(root, column=("c1", "c2"), show='headings')
tree.column("#1", width=90, anchor=CENTER)
tree.heading("#1", text="Features")
tree.column("#2", width=60,anchor=CENTER)
tree.heading("#2", text="Value")
tree.place(x=550, y=50, width=160)
##########
lbPanel=Label(text="Region of Interest",anchor="w")
lbPanel.place(x = 25, y = 30 , width=150, height=25)
picPanel = Label(root, width= 256, borderwidth=2, relief='groove')
picPanel.place(x=25, y=50, width=256, height=256)

lbSegmen=Label(text="Segmentation",anchor="w")
lbSegmen.place(x = 290, y = 30 , width=75, height=25)
picSegmen = Label(root, width= 256, borderwidth=2, relief='groove')
picSegmen.place(x=290, y=50, width=256, height=256)

btn_detecting = Button(root, text="Open File", command=open_file)
btn_detecting.place(x=25, y=5, width=75, height=20)

lbSVM = Label(text="SVM Predict")
lbSVM.place(x = 25, y = 320 , width=75, height=25)
hasilSVM = Label(root,text="",borderwidth=2, relief='groove')
hasilSVM.place(x=125, y=320, width=200, height=25)

lbKNN = Label(text="KNN Predict")
lbKNN.place(x = 25, y = 350 , width=75, height=25)
hasilKNN = Label(root,text="",borderwidth=2, relief='groove')
hasilKNN.place(x=125, y=350, width=200, height=25)

btn_training = Button(root, text="Training SVM", command=training)
btn_training.place(x=25, y=375, width=100, height=20)

lbEvaluationKNN = Label(text=".",anchor='w')
lbEvaluationKNN.place(x = 125, y = 400 , width=200, height=25)

btn_knn = Button(root, text="KNN Evaluation", command=knn_evaluation)
btn_knn.place(x=25, y=400, width=100, height=20)

lbEvaluationSVM = Label(text=".",anchor='w')
lbEvaluationSVM.place(x = 125, y = 375 , width=400, height=25)




root.mainloop()
